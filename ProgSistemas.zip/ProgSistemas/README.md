# Programação de Sistemas

#### Integrantes do Grupo:
  * __[Juan Burtet](https://github.com/juan-burtet) [Líder]__
    > Carregador.
  * __[Leonardo Coelho](https://github.com/leoGCoelho) [Vice-Líder]__
    > Interface Gráfica.
  * __[Cândido Moraes](https://github.com/candidosmoraes)__
    > Ligador.
  * __[Felipe Gruendemann](https://github.com/FelipeGruend)__
    > Macros.
  * __[Isabelle Azevedo](https://github.com/isabelleaazevedo)__
    > Montador + Instruções
  * __[Thales Castro](https://github.com/cineasthales)__
    > Montador + Instruções

#### Linguagem Utilizada:
  * _[Java](https://www.java.com)_

#### IDE Utilizada:
  * _[NetBeans](https://netbeans.org)_
